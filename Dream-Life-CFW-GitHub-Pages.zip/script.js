const nav=document.querySelector('.nav');document.querySelector('.menu').onclick=()=>nav.classList.toggle('open');
const toast=document.getElementById('toast');
function notify(t){toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2600)}
function apply(job){notify('تم اختيار التقديم على: '+job+' — اربط زر التقديم بنموذجك لاحقاً.')}
function buy(item){notify('تم اختيار '+item+' — أضف رابط متجر Discord/ Tebex في script.js.')}
function connect(e){e.preventDefault();notify('ضع رابط اتصال FiveM الخاص بك في الدالة connect داخل script.js.')}
